package com.emw_calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class  LogInSucessActivity extends AppCompatActivity {
    EditText formular_EditText;
    TextView ExportText;
    TextView result_text;
    Button result_Btn;
    Button calclulate_Reset_Btn;
    Button contact_btn,exportBtn;

    private PermissionsChecker mPermissionsChecker; // 权限检测器
    private final int RESULT_CODE_LOCATION = 0x001;

    String[] permsLocation = {//"android.permission.READ_PHONE_STATE",
            "android.permission.ACCESS_COARSE_LOCATION",
            //"android.permission.ACCESS_FINE_LOCATION",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_sucess);
        SysApplication.getInstance().addActivity(this);

        ExportText = findViewById(R.id.Export_Text);
        ExportText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogInSucessActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        formular_EditText = (EditText) findViewById(R.id.formular_EditText);
        result_text = (TextView) findViewById(R.id.Result_Text);
        result_Btn = (Button) findViewById(R.id.Result_Button);
        contact_btn=findViewById(R.id.Contact_btn);
        mPermissionsChecker = new PermissionsChecker(LogInSucessActivity.this);

        exportBtn =findViewById(R.id.Export_btn);
        exportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPermissionsChecker.lacksPermissions(permsLocation)) {
                    ActivityCompat.requestPermissions(LogInSucessActivity.this, permsLocation, RESULT_CODE_LOCATION);
                     }
                screenShot();
            }
        });


        contact_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogInSucessActivity.this, SendMailActivity.class);
                startActivity(intent);
            }
        });
        calclulate_Reset_Btn = (Button) findViewById(R.id.Calculate_Reset);
        calclulate_Reset_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formular_EditText.setText("");
                result_text.setText("");
            }
        });

    }
    private void screenShot() {
        View dView = getWindow().getDecorView();
        dView.setDrawingCacheEnabled(true);
        dView.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(dView.getDrawingCache());
        if (bitmap != null) {
            try {
                saveBitmap(bitmap);
            } catch (Exception e) {
            }
        }

    }
    private void saveBitmap(Bitmap bmp) throws IOException {
        File childFolder = Environment.getExternalStoragePublicDirectory(Environment
                .DIRECTORY_PICTURES);
        File imageFile = new File(childFolder.getAbsolutePath() + "/" + System.currentTimeMillis
                () + ".jpg");
        OutputStream fOut = new FileOutputStream(imageFile);
        bmp.compress(Bitmap.CompressFormat.JPEG, 60, fOut);//将bg输出至文件
        fOut.flush();
        fOut.close(); // do not forget to close the stream
        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile
                (imageFile)));
        //ToastUtils.showShort(getString(R.string.success));
        Toast.makeText(getApplicationContext(),"Storage went sucess!", Toast.LENGTH_SHORT).show();
    }

    public class PermissionsChecker {
        private final Context mContext;

        public PermissionsChecker(Context context) {
            mContext = context.getApplicationContext();
        }

        // 判断权限集合
        public boolean lacksPermissions(String... permissions) {
            for (String permission : permissions) {
                if (lacksPermission(permission)) {
                    return true;
                }
            }
            return false;
        }

        // 判断是否缺少权限
        private boolean lacksPermission(String permission) {
            return ContextCompat.checkSelfPermission(mContext, permission) ==
                    PackageManager.PERMISSION_DENIED;
        }
    }


    public void doCount(View view) {
        String str = formular_EditText.getText().toString();

        if(str.isEmpty()){
            Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
            startActivity(intent);

        }else {
            String subStr = str.substring(0, 1);
            char[] chStr = subStr.toCharArray();
            char capStr = chStr[0];
            char[] wholeStr=str.toCharArray();
            int strLength=str.length();
            int laterStrLoc= strLength-1;
            char laterStr= wholeStr[laterStrLoc];
            if (str.length() > 15) {
                Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                startActivity(intent);
            } else if (!Character.isLetter(capStr)) {
                Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                startActivity(intent);
            } else if (Character.isLetter(laterStr)) {
                Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                startActivity(intent);
            } else {
                Pattern p = Pattern.compile("\\d+");
                String[] wordStr = p.split(str);
                for (int i = 0; i < wordStr.length; i++) {
                    wordStr[i] = getConvert(wordStr[i]);
                }

                Pattern newp = Pattern.compile("[a-zA-Z]");//½«Êý×Ö´æÈëÊý×énumb
                Matcher newm = newp.matcher(str);
                String str_new = newm.replaceAll(",");//Ìæ»»ËùÓÐ×ÖÄ¸Îª£¬
                String newStr = str_new.substring(1);//É¾³ýÊ×Î»·ÇÊý×Ö
                String[] numb = newStr.split(",");//ÒÔ£¬·Ö¸î´æÈëÊý×é

                double[] finalWordStrValue = new double[wordStr.length];//Æ¥ÅäÏàÍ¬µÄÔªËØ
                String[] wordStrLib = {"H",	"D",	"T",	"He",	"Li",	"Be",	"B",	"C",	"N",	"O",	"F",	"Ne",	"Na",	"Mg",	"Al",	"Si",	"P",	"S",	"Cl",	"Ar",	"K",	"Ca",	"Sc",	"Ti",	"V",	"Cr",	"Mn",	"Fe",	"Co",	"Ni",	"Cu",	"Zn",	"Ga",	"Ge",	"As",	"Se",	"Br",	"Kr",	"Rb",	"Sr",	"Y",	"Zr",	"Nb",	"Mo",	"Tc",	"Ru",	"Rh",	"Pd",	"Ag",	"Cd",	"In",	"Sn",	"Sb",	"Te",	"I",	"Xe",	"Cs",	"Ba",	"La",	"Ce",	"Pr",	"Nd",	"Pm",	"Sm",	"Eu",	"Gd",	"Tb",	"Dy",	"Ho",	"Er",	"Tm",	"Yb",	"Lu",	"Hf",	"Ta",	"W",	"Re",	"Os",	"Ir",	"Pt",	"Au",	"Hg",	"Tl",	"Pb",	"Bi",	"Po",	"At",	"Rn",	"Fr",	"Ra",	"Ac",	"Th",	"Pa",	"U",	"Np",	"Pu",	"Am",	"Cm",	"Bk",	"Cf",	"Es",	"Fm",	"Md",	"No",	"Lr",	"Rf",	"Db",	"Sg",	"Bh",	"Hs",	"Mt",	"Ds",	"Rg",	"Cn",	"Nh",	"Fl",	"Mc",	"Lv",	"Ts",	"Og"};
                double[] wordStrLibValue = {1.00782,	2.014101,	3.01604,	3.01602,	6.01512,	9.01218,	10.01293,	12.00000,	14.00307,	15.99491,	18.9984,	19.99244,	22.98976,	23.98504,	26.98153,	27.97692,	30.97376,	31.97207,	34.96885,	35.96754,	38.9637,	39.96259,	44.9559,	45.95262,	49.94715,	49.94604,	54.93804,	53.9396,	58.93319,	57.93534,	62.92959,	63.92914,	68.92557,	69.92424,	74.92159,	73.92247,	78.91833,	77.92036,	84.91178,	83.91341,	88.90584,	89.90469,	92.90637,	91.9068,	96.90636,	95.90759,	102.90549,	101.9056,	106.90509,	105.90645,	112.90406,	111.90482,	120.90381,	119.90405,	126.90447,	123.90589,	132.90545,	129.90632,	137.90711,	135.90712,	140.90765,	141.90772,	144.91275,	143.912,	150.91985,	151.91979,	158.92535,	155.92428,	164.93032,	161.92878,	168.93421,	167.93388,	174.94077,	173.94004,	179.94746,	179.94671,	184.95295,	183.95248,	190.96058,	189.95992,	196.96656,	195.96583,	202.97234,	203.97304,	208.98039,	208.98243,	209.98714,	210.9906,	223.01973,	223.0185,	227.02775,	230.03313,	231.03588,	233.03963,	236.04657,	238.04956,	241.05682,	243.06138,	247.0703,	249.07485,	252.08298,	257.0951,	258.09843,	259.10103,	262.10961,	267.12179,	268.12567,	271.13393,	272.13826,	270.13429,	276.15159,	281.16451,	280.16514,	285.17712,	284.17873,	289.19042,	288.19274,	293.20449,	292.20746,	294.21392};

                for (int i = 0; i < finalWordStrValue.length; i++) {
                    finalWordStrValue[i] = 0.0000;
                }

                for (int i = 0; i < wordStr.length; i++)//½«Æ¥ÅäÔªËØµÄ·Ö×ÓÁ¿´Ó¿âÖÐÌáÈ¡³öÀ´
                {
                    for (int j = 0; j < wordStrLib.length; j++) {
                        if (wordStr[i].equals(wordStrLib[j])) {
                            finalWordStrValue[i] = wordStrLibValue[j];
                        }
                    }
                }
                int t_ime = 4;
                for (int i = 0; i < finalWordStrValue.length; i++) {
                    double t = 0.0000;
                    if (finalWordStrValue[i] == t) {
                        t_ime = 2;
                    }
                }
                if (t_ime > 2) {
                    double[] sum = new double[wordStr.length];
                    double[] intnumb = new double[wordStr.length];
                    for (int i = 0; i < wordStr.length; i++) {
                        intnumb[i] = Double.parseDouble(numb[i]);
                        sum[i] = intnumb[i] * finalWordStrValue[i];

                    }

                    double suma = 0.0000;
                    for (int i = 0; i < wordStr.length; i++) {

                        suma = suma + sum[i];
                        //if (suma > 1000.0000) {
                        //   break;
                        //}
                    }

                    if (suma > 1000.000) {
                        Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                        startActivity(intent);
                    }
                    else if (suma == 0.000) {
                        Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                        startActivity(intent);}
                    else {
                        NumberFormat ddf1 = NumberFormat.getNumberInstance();
                        ddf1.setMaximumFractionDigits(4);
                        String sFinal = ddf1.format(suma);
                        //System.out.println(sFinal);

                        result_text.setText(sFinal);
                        //System.out.println(suma);
                    }


                } else {
                    Intent intent = new Intent(LogInSucessActivity.this, FomulaErrorActivity.class);
                    startActivity(intent);
                }

            }
        }

    }


    public static String getConvert(String str)
    {

        String fir_st = str.substring(0, 1);//
        String af_ter = str.substring(1);
        fir_st = fir_st.toUpperCase();
        af_ter = af_ter.toLowerCase();
        return fir_st + af_ter;
    }
}