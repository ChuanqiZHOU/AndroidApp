package com.emw_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.security.MessageDigest;

public class MainActivity extends AppCompatActivity {
    private EditText mSerialNum,mEmailAdress;
    private TextView mTextViewContact;
    private Button mbtn_Go;
    private Button mbtn_Reset;
    private Button mbtnExit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SysApplication.getInstance().addActivity(this);
        mEmailAdress = findViewById(R.id.EmailAdress);

        mSerialNum= (EditText) findViewById(R.id.SerialNum);
        mbtn_Go = (Button) findViewById(R.id.mbtn_Go);
        mbtn_Reset = (Button) findViewById(R.id.mbtn_Reset);
        mTextViewContact = findViewById(R.id.TextView_Contact);
        mbtnExit = findViewById(R.id.mbtn_Exit);
        mbtnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //关闭整个程序
                SysApplication.getInstance().exit();
            }
        });

        mTextViewContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SendMailActivity.class);
                startActivity(intent);
            }
        });
        mbtn_Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SerialNumber = mSerialNum.getText().toString();
                String emailStr= mEmailAdress.getText().toString();
                Boolean Deci_Para=true;
                for(int i=0;i<1;i++){
                    if(emailStr == null || emailStr.isEmpty()){
                        Deci_Para=false;
                        //System.out.println("the string is empty");
                        break;
                    }else if (emailStr.length() <6 || emailStr.length() >50){
                        Deci_Para=false;
                        //System.out.println("the string is smaller or larger");
                        break;
                    } else{
                        if(emailrule(emailStr)==false){
                            Deci_Para=false;

                        }else{
                            Deci_Para=true;
                            //System.out.println("ÊäÈëÕýÈ·");
                        }
                    }

                }

                for(int t=0;t<1;t++) {
                    if (Deci_Para == false) {
                        //System.out.println("´íÎó");
                        Intent intent = new Intent(MainActivity.this, LogInErrorActivity.class);
                        startActivity(intent);
                        break;
                    }
                    String final_pwd = getmd5(emailStr);
                    String extra_pwd = final_pwd.substring(4,9);

                    if (SerialNumber.equals(extra_pwd)){
                        Intent intent = new Intent(MainActivity.this, LogInSucessActivity.class);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(MainActivity.this, LogInErrorActivity.class);
                        startActivity(intent);
                    }
                }
            }
        });
        mbtn_Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSerialNum.setText("");
            }
        });






    }



    private boolean emailrule(String emailStr) {
        if(emailStr.indexOf("@")==-1){

            return false; }
        if(emailStr.indexOf("@")!=emailStr.lastIndexOf("@")){

            return false; }
        if(emailStr.indexOf(".")==-1){

            return false; }
        if(emailStr.indexOf("@")>emailStr.indexOf(".")){

            return false; }
        if(emailStr.startsWith("@")){

            return false; }
        if(emailStr.endsWith(".")){

            return false; }
        if(emailStr.indexOf("@.")!=-1){

            return false; }

        return true;

    }
    private static String getmd5(String originString){
        if (originString!=null) {
            try {

                MessageDigest md5 = MessageDigest.getInstance("MD5");

                byte[] results = md5.digest(originString.getBytes());

                String result = byteArrayToHexString(results);
                return result;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null; }

    private static String byteArrayToHexString(byte[] b){
        StringBuffer resultSb = new StringBuffer();
        for(int i=0;i<b.length;i++){
            resultSb.append(byteToHexString(b[i]));
        }
        return resultSb.toString();
    }


    private static String byteToHexString(byte b){
        String[] hexDigits = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
        int n = b;
        if(n<0)
            n=256+n;
        int d1 = n/16;
        int d2 = n%16;
        return hexDigits[d1] + hexDigits[d2];
    }
}
