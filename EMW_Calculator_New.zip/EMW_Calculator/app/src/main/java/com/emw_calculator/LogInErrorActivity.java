package com.emw_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LogInErrorActivity extends AppCompatActivity {
    private Button LogError_Returnbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_error);
        SysApplication.getInstance().addActivity(this);

        LogError_Returnbtn = (Button)findViewById(R.id.logErrorReturn);
        LogError_Returnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogInErrorActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
