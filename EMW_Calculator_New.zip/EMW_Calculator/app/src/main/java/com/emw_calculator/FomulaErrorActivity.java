package com.emw_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FomulaErrorActivity extends AppCompatActivity {
    private Button capError_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fomula_error);
        SysApplication.getInstance().addActivity(this);

        capError_btn=(Button) findViewById(R.id.capError_Return);

        capError_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FomulaErrorActivity.this, LogInSucessActivity.class);
                startActivity(intent);
            }
        });
    }
}
